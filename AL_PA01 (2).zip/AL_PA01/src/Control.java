import java.util.*;
import java.io.*;

public class Control {
	public static void main(String[] args) throws FileNotFoundException{
		int i = 0;
		String[] parameter = new String[2];

		PrintStream print1 = new PrintStream(new File("RandomizedResult"+".txt"));
		PrintStream print2 = new PrintStream(new File("DeterministicResult"+".txt"));
		long[] time;
		for(i=1;i<=100;i++) {
			parameter[0] = "Random_output"+Integer.toString(100*i)+".txt";
			parameter[1] = Integer.toString(50*i);
			time = Test(parameter);
			print1.println(time[0]);
			print2.println(time[1]);
		}
	}
	
	public static long[] Test(String[] args) throws FileNotFoundException{
//		int[] hey = new int[10];
		Scanner input = new Scanner(new File(args[0]));
		int i_th = Integer.parseInt(args[1]);
		int numCount = 0;
		while(input.hasNextInt()) {
			input.nextInt();
			numCount++;
		}
		int A[] = new int[numCount];
		input = new Scanner(new File(args[0]));
		int i=0;
		
		while(input.hasNextInt()) {
			A[i] = input.nextInt();
			i++;
		}
		
		int copy[] = A;
		
		Select_Class Select = new Select_Class();
		long startTime = System.nanoTime();
		int j = Select.Randomized_Select(A, 0, A.length-1, i_th);
		long stopTime = System.nanoTime();
		long elapsedTime_Randomized = stopTime-startTime;
		
		System.out.println("----------Randomized-Select----------");
		System.out.println("i-th smallest number : "+j);
		System.out.println("Elapsed Time : "+elapsedTime_Randomized);
		
		A = copy;
		startTime = System.nanoTime();
		System.out.println("i_th is "+i_th);
		int k = Select.Deterministic_Select(A, 0, A.length-1, i_th);
		stopTime = System.nanoTime();
		long elapsedTime_Deterministic = stopTime-startTime;
		System.out.println("----------Deterministic-Select----------");
		System.out.println("i-th smallest number : "+k);
		System.out.println("Elapsed Time : "+elapsedTime_Deterministic);
		System.out.println();
		
		long time[] = new long[2];
		time[0] = elapsedTime_Randomized;
		time[1] = elapsedTime_Deterministic;
		String array[] = new String[3];
		array[0] = args[1];
		array[1] = args[0];
		array[2] = Integer.toString(j);
		Checker.check(array);
		
		array[2] = Integer.toString(k);
		Checker.check(array);
		
		return time;
	}
}
