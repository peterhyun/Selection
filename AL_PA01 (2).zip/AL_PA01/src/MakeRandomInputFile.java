import java.io.*;
import java.util.*;

public class MakeRandomInputFile {
	public static void main(String[] args) throws FileNotFoundException{
		for(int i=1;i<=100;i++) {
			make(100*i);
		}
	}
	
	public static void make(int size) throws FileNotFoundException{
		PrintStream randomPrint = new PrintStream(new File("Random_output"+size+".txt"));
		
		int[] output = new int[size];
		
		for(int i=0;i<size;i++) {
			output[i] = i-1;
		}
		
		shuffleArray(output);
		
		StringBuilder builder = new StringBuilder();
		for(int i=0;i<size;i++) {
			builder.append(output[i]);
			builder.append(" ");
			if((i+1)%20==0) {
				builder.append("\n");
			}
		}
		
		String temp = builder.toString();
		randomPrint.println(temp);
		System.out.println(temp);
	}
	
	private static void shuffleArray(int[] array)
	{
	    int index, temp;
	    Random random = new Random();
	    for (int i = array.length - 1; i > 0; i--)
	    {
	        index = random.nextInt(i + 1);
	        temp = array[index];
	        array[index] = array[i];
	        array[i] = temp;
	    }
	}
	
}