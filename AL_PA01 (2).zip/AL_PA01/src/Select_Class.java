import java.util.*;

public class Select_Class {
	
	int Randomized_Select(int[] A, int p, int r, int i){	//p is left, r is right, i is the ith value (counts from 1) we wanna find.
		if(p==r)	//i has to be 1 in this case.
			return A[p];
		
		Random temp = new Random();
		int length = r-p+1;	//Number of all possible candidates for random number
		int pivot = (temp.nextInt(length)) + p; //(p~length-1+p) //location of the pivot
		
		int q = partition(A,p,r,pivot);	//returns index of the partition.
		int k = q-p+1; //number of elements in the first subarray + the pivot element.
		
		if(i==k) {
			return A[q];
		}
		
		//The crucial part
		else if(i<k) {
			return Randomized_Select(A,p,q-1,i);
		}
		else {
			return Randomized_Select(A,q+1,r,i-k);	//now find the (i-k)th smallest element.
		}
	}
	
	int Deterministic_Select(int[] A, int p, int r, int i) {
		int length = r-p+1;
		if(length<=5) {	//i should also be smaller or equal to 5
			insertion_Sort_Partial(A,p,r);
			return A[p+i-1];
		}
		
		//2. make the small arrays of size 5(last array can be smaller than 5) each
		int numOfArrays = length%5==0 ? (length/5) : (length/5+1);
		int neededArrays[][] = new int[numOfArrays][5];
		Arrays.fill(neededArrays[numOfArrays-1],-2147483647);	//dummy values
		
		for(int j=0;j<numOfArrays;j++) {
			for(int k=0;k<5 && (p+5*j+k)<=r;k++) {
				neededArrays[j][k] = A[p+5*j+k];
			}
		}
		
		//3. find the median of each arrays
		int medianArray[] = new int[numOfArrays];
		int temp2 = 0;
		for(int j=0;j<numOfArrays;j++) {
			insertion_Sort(neededArrays[j]);
			temp2 = neededArrays[j].length;
			if(j == numOfArrays-1) {
				temp2 = 0;
				for(int k=0;k<neededArrays[j].length;k++) {
					if(neededArrays[j][k]!=-2147483647)
						temp2++;
				}
				medianArray[j] = neededArrays[j][4-(temp2/2)];
			}
			else {
				medianArray[j] = neededArrays[j][temp2/2];
			}
		}
		
		//4. Get the median among the medians.		
		int king_Median = Deterministic_Select(medianArray,0,numOfArrays-1, (numOfArrays+1)/2);
		//Now we got the perfect pivot king_Median
		
		//4.5 Have to get the king_Median's index within the whole Array
		int king_Median_Index = p;
		while(king_Median!=A[king_Median_Index]) {
			king_Median_Index++;
		}
		
		//5. Partition the whole array
		int q = partition(A,p,r,king_Median_Index);	//returns index of the pivot's location.
		int k = q-p+1; //number of elements in the first subarray + the pivot element.
		
		if(i==k) {
			return A[q];
		}
		
		//The crucial part
		//6. Choose the appropriate subarray.
		else if(i<k) {
			return Deterministic_Select(A,p,q-1,i);
		}
		else {
			return Deterministic_Select(A,q+1,r,i-k);	//now find the (i-k)th smallest element.
		}
	}
	
	int partition(int[] A, int p, int r, int pivot) {
		//switch the last index element and the pivot element. Moving the pivot to the end.
		int store = A[r];
		A[r] = A[pivot];
		A[pivot] = store;
		
		//now swapping
		int i = p-1;
		for(int j=p;j<r;j++) {
			if(A[j]<=A[r]) {
				i++;
				store = A[i];
				A[i] = A[j];
				A[j] = store;
			}
		}
		store = A[r];
		A[r] = A[i+1];
		A[i+1] = store;
		return (i+1);	//location of the pivot
	}
	
	void insertion_Sort(int[] A) {
		for(int j=1;j<A.length;j++) {
			int key = A[j];
			int i = j-1;
			while(i>=0 && A[i]>key) {
				A[i+1] = A[i];
				i--;
			}
			A[i+1] = key;
		}
	}
	
	void insertion_Sort_Partial(int[] A, int p, int q) {
		int length = q-p+1;
		for(int j=p+1;j<(p+length);j++) {
			int key = A[j];
			int i = j-1;
			while(i>=p && A[i]>key) {
				A[i+1] = A[i];
				i--;
			}
			A[i+1] = key;
		}
	}
}