import java.io.*;
import java.util.*;

public class Checker {
	@SuppressWarnings("resource")
	public static boolean check(String args[]) throws FileNotFoundException{
			//args[0] is the order we're trying to look for, args[1] is the file name, args[2] is the i_th_element.
		int order = Integer.parseInt(args[0]);
		int i_th_element = Integer.parseInt(args[2]);
		
		Scanner input = new Scanner(new File(args[1]));
		int numCount = 0;
		while(input.hasNextInt()) {
			input.nextInt();
			numCount++;
		}
		int A[] = new int[numCount];
		input = new Scanner(new File(args[1]));
		int i=0;
		
		while(input.hasNextInt()) {
			A[i] = input.nextInt();
			i++;
		}
		
		int realOrder = 0;
		for(int j=0;j<A.length;j++) {
			if(i_th_element>=A[j]) {
				realOrder++;
			}
		}
		
		System.out.println("The element "+i_th_element+"'s actual order is "+realOrder);
		if(realOrder == order) {
			System.out.println("Correct");
			return true;
		}
		else {
			System.out.println("Wrong");
			return false;
		}
	}
}