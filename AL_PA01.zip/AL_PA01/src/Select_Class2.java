import java.util.*;
import java.io.*;

public class Select_Class2 {
	public static void main(String[] args) throws FileNotFoundException {
		File file = new File("output.txt");
		Scanner input = new Scanner(file);
		int numCount = 0;
		while(input.hasNextInt()) {
			input.nextInt();
			numCount++;
		}
		
		input = new Scanner(file);
		
		LinkedList<Integer> A = new LinkedList<Integer>();
		while(input.hasNextInt()) {
			A.add(input.nextInt());
		}
		
		//System.out.println("A.size()-1 is "+(A.size()-1));
		int i = Randomized_Select(A,0,A.size()-1,3);	//-3 is the right answer
		System.out.println(i);
	}
	
	static int temp = 0;
	static int Randomized_Select(LinkedList<Integer> A, int p, int r, int i){	//p is left, r is right, i is the ith value (counts from 1) we wanna find.
		if(p==r)	//i has to be 1 in this case.
			return A.get(p);
		
		Random temp = new Random();
		int length = r-p+1;	//Number of all possible candidates for random number
		int pivot = 12;//(temp.nextInt(length)) + p; //(p~length-1+p) //location of the pivot
		
		int[] B = new int[length];
		for(int j=0;j<length;j++) {
			B[j] = A.get(j);
		}
		
		int q = partition(B,p,r,pivot);	//returns index of the partition.
		int k = q-p+1; //number of elements in the first subarray + the pivot element.
		
		if(i==k) {
			return A.get(q);
		}
		//The crucial part
		else if(i<k) {
			System.out.println("left");
			return Randomized_Select(A,p,q-1,i);
		}
		else {
			System.out.println("right");
			return Randomized_Select(A,q+1,r,i-k);	//now find the (i-k)th smallest element.
		}
	}
	
	static int partition(int[] A, int p, int r, int pivot) {
		//switch the last index element and the pivot element. Moving the pivot to the end.
		int store = A[r];
		System.out.println("size of A is "+A.length+" and pivotIndex is "+pivot);
		A[r] = A[pivot];
		A[pivot] = store;
		
		//now swapping
		int i = p-1;
		for(int j=p;j<r;j++) {
			if(A[j]<=A[r]) {
				i++;
				store = A[i];
				A[i] = A[j];
				A[j] = store;
			}
		}
		store = A[r];
		A[r] = A[i+1];
		A[i+1] = store;
		System.out.println("result of partition is "+Arrays.toString(A));
		return (i+1);	//location of the pivot
	}
	
	static int Deterministic_Select(int[] A, int p, int r, int i) {
		System.out.println(++temp+" -th recursion");
		int length = r-p+1;
		if(length<=5) {	//i should also be smaller or equal to 5
			System.out.println("p,r,i is "+p+", "+r+", "+i);
			insertion_Sort(A);
			return A[p+i-1];
		}
		
		//2. make the small arrays of size 5(last array can be smaller than 5) each
		int numOfArrays = length%5==0 ? (length/5) : (length/5+1);
		int neededArrays[][] = new int[numOfArrays][5];
		for(int j=p;j<numOfArrays;j++) {
			for(int k=p;k<5 && (5*j+k)<length;k++) {
				neededArrays[j][k] = A[5*j+k];
			}
		}
		
		for(int j=0;j<numOfArrays;j++) {
			System.out.println(Arrays.toString(neededArrays[j]));
		}
		
		//3. find the median of each arrays
		int medianArray[] = new int[numOfArrays];
		int temp2 = 0;
		for(int j=0;j<numOfArrays;j++) {
			insertion_Sort(neededArrays[j]); //<---�̰� ���� �߻���Ŵ.
			temp2 = neededArrays[j].length;
			if(j == numOfArrays-1) {
				System.out.println(Arrays.toString(neededArrays[j]));
				temp2 = 0;
				for(int k=0;k<neededArrays[j].length;k++) {
					if(neededArrays[j][k]!=0)
						temp2++;
				}
				System.out.println("temp2 is "+temp2);
				medianArray[j] = neededArrays[j][4-(temp2/2)];
			}
			else {
				medianArray[j] = neededArrays[j][temp2/2];
			}
		}
		
		System.out.println("Median Array is "+Arrays.toString(medianArray));
		//4. Get the median among the medians.
		/*for(int j=0;j<A.length;j++) {
			System.out.println("A[j] is "+A[j]);
		}*/
		
		int king_Median = Deterministic_Select(medianArray,0,numOfArrays-1, numOfArrays/2+1);
		System.out.println("king_Median is "+king_Median);
		//Now we got the perfect pivot king_Median
		
		//4.5 Have to get the king_Median's index within the whole Array
		int king_Median_Index = 0;
		
		//System.out.println("A array is "+Arrays.toString(A));
		
		for(int j=p;j<length;j++) {
			if(king_Median != A[j]) {
				king_Median_Index++;
			}
			else
				break;
		}
		System.out.println("king_Median_Index is "+king_Median_Index);
		//5. Partition the whole array
		int q = partition(A,p,r,king_Median_Index);	//returns index of the pivot's location.
		int k = q-p+1; //number of elements in the first subarray + the pivot element.
		
		System.out.println("q is "+q+", "+"k is "+k);
		if(i==k) {
			return A[q];
		}
		
		//The crucial part
		//6. Choose the appropriate subarray.
		else if(i<k) {
			System.out.println("left");
			System.out.println(p+", "+(q-1)+", "+i);
			return Deterministic_Select(A,p,q-1,i);
		}
		else {
			System.out.println("right");
			System.out.println(q+1+", "+r+", "+(i-k));
			return Deterministic_Select(A,q+1,r,i-k);	//now find the (i-k)th smallest element.
		}
	}
	/*
	static int partition(int[] A, int p, int r, int pivot) {
		//switch the last index element and the pivot element. Moving the pivot to the end.
		int store = A[r];
		//System.out.println("size of A is "+A.length+" and pivotIndex is "+pivot);
		A[r] = A[pivot];
		A[pivot] = store;
		
		//now swapping
		int i = p-1;
		for(int j=p;j<r;j++) {
			if(A[j]<=A[r]) {
				i++;
				store = A[i];
				A[i] = A[j];
				A[j] = store;
			}
		}
		store = A[r];
		A[r] = A[i+1];
		A[i+1] = store;
		System.out.println("result of partition is "+Arrays.toString(A));
		return (i+1);	//location of the pivot
	}*/
	/*
	int Deterministic_Select(LinkedList<Integer> A, int p, int r, int i) {
		System.out.println(++temp+" -th recursion");
		int length = r-p+1;
		if(length<=5) {	//i should also be smaller or equal to 5
			//System.out.println(Arrays.toString(A));
			int[] B = new int[length];
			for(int j=0;j<length;j++) {
				B[j] = A.get(j);
			}
			insertion_Sort(B);
			return B[p+i-1];
		}
		
		//2. make the small arrays of size 5(last array can be smaller than 5) each
		int numOfArrays = length%5==0 ? (length/5) : (length/5+1);
		//System.out.println("nOA is "+numOfArrays);
		List<Integer>[] neededArrays = new List[numOfArrays];
		//int neededArrays[][] = new int[numOfArrays][5];
		for(int j=0;j<numOfArrays;j++) {
			neededArrays[j] = new LinkedList<Integer>();
			for(int k=0;k<5 && (5*j+k)<A.size();k++) {
				neededArrays[j].add(A.get(5*j+k));
			}
		}
		
		//3. find the median of each arrays
		LinkedList<Integer> medianArray = new LinkedList<Integer>();
		int temp = 0;
		int[] C;
		for(int j=0;j<numOfArrays;j++) {
			C = new int[neededArrays[j].size()];
			for(int k=0;k<neededArrays[j].size();k++) {
				C[k] = neededArrays[j].get(k);
			}
			insertion_Sort(C);
			temp = neededArrays[j].size();
			medianArray.add(C[temp/2]);
		}
		
		//4. Get the median among the medians.
		for(int j=0;j<A.size();j++) {
			System.out.println("A.size() is "+A.size());
		}
		
		int king_Median = Deterministic_Select(medianArray,0,numOfArrays-1, numOfArrays/2);
		System.out.println("king_Median is "+king_Median);
		//Now we got the perfect pivot king_Median
		
		//4.5 Have to get the king_Median's index within the whole Array
		int king_Median_Index = 0;
		
		
		
		for(int j=0;j<A.size();j++) {
			if(king_Median!=A.get(j)) {
				king_Median_Index++;
			}
		}
		
		//5. Partition the whole array
		int[] B = new int[length];
		for(int j=0;j<length;j++) {
			B[j] = A.get(j);
		}
		int q = partition(A,p,r,king_Median_Index);	//returns index of the pivot's location.
		int k = q-p+1; //number of elements in the first subarray + the pivot element.
		
		if(i==k) {
			return A.get(q);
		}
		
		//The crucial part
		//6. Choose the appropriate subarray.
		else if(i<k) {
			return Deterministic_Select(A,p,q-1,i);
		}
		else {
			return Deterministic_Select(A,q+1,r,i-k);	//now find the (i-k)th smallest element.
		}
	}
	
	int partition(LinkedList<Integer> A, int p, int r, int pivot) {
		//switch the last index element and the pivot element. Moving the pivot to the end.
		int store = A.get(r);
		System.out.println("size of A is "+A.size()+" and pivotIndex is "+pivot);
		A.remove(r);
		A.add(r, A.get(pivot));
		A.remove(pivot);
		A.add(pivot,store);
		
		//now swapping
		int i = p-1;
		for(int j=p;j<r;j++) {
			if(A.get(j)<=A.get(r)) {
				i++;
				store = A.get(i);
				A.remove(i);
				A.add(i,A.get(j));
				A.remove(j);
				A.add(j,store);
			}
		}
		store = A.get(r);
		A.remove(r);
		A.add(r,A.get(i+1));
		A.remove(i+1);
		A.add(i+1,store);
		return (i+1);	//location of the pivot
	}
	*/
	
	
	static void insertion_Sort(int[] A) {
		for(int j=1;j<A.length;j++) {
			int key = A[j];
			int i = j-1;
			while(i>=0 && A[i]>key) {
				A[i+1] = A[i];
				i--;
			}
			A[i+1] = key;
		}
	}
}